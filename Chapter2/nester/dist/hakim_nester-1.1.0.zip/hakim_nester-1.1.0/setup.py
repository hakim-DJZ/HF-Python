from distutils.core import setup

setup(
    name            = 'hakim_nester',
    version         = '1.1.0',
    py_modules      = ['hakim_nester'],
    author          = 'hakim',
    author_email    = 'hakim.sellaoui@gmail.com', 
    description     = 'A simple printer of nested lists',
    )
