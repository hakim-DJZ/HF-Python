from distutils.core import setup

setup(
    name            = 'Coach',
    version         = '1.0.0',
    py_modules      = ['Coach'],
    author          = 'hakim',
    author_email    = 'hakim.sellaoui@gmail.com', 
    description     = "Opens Coach data, stripping the lines and seperates data by ','"
    )
