from distutils.core import setup

setup(
    name            = 'sanitize',
    version         = '1.0.0',
    py_modules      = ['sanitize'],
    author          = 'hakim',
    author_email    = 'hakim.sellaoui@gmail.com', 
    description     = 'Chages colons and dashes to periods',
    )
